package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.widget.SeekBar.*;
import android.content.*;

public class MainActivity extends Activity{
	public int r, g,b,a;
	public TextView ima;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		ima = (TextView)findViewById(R.id.mainImageView);
		ima.setBackgroundColor(Color.argb(255,r,g,b));
    }
	
	public void onclick(View view){
		Color();
	}
	
	private void Color() {
		AlertDialog.Builder customizeDialog = 
			new AlertDialog.Builder(MainActivity.this);
		final View dialogView = LayoutInflater.from(MainActivity.this)
			.inflate(R.layout.color,null);
		customizeDialog.setView(dialogView);
		final TextView colorTextView = (TextView)dialogView.findViewById(R.id.colorBackground);
		colorTextView.setBackgroundColor(Color.argb(255,0,0,0));
		final TextView colorTextView1 = (TextView)dialogView.findViewById(R.id.colorTextView1);
		colorTextView1.setText(0+"");
		final TextView colorTextView2 = (TextView)dialogView.findViewById(R.id.colorTextView2);
		colorTextView2.setText(0+"");
		final TextView colorTextView3 = (TextView)dialogView.findViewById(R.id.colorTextView3);
		colorTextView3.setText(0+"");
		SeekBar colorSeekBar1 = (SeekBar)dialogView.findViewById(R.id.colorSeekBar1);
		colorSeekBar1.setMax(255);
		colorSeekBar1.setProgress(0);
		colorSeekBar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
				@Override
				public void onProgressChanged(SeekBar p1, int p2, boolean p3){

					String f = Integer.toString(p2);
					colorTextView1.setText(f+"");
					a=Integer.parseInt((String) colorTextView1.getText());
					g = Integer.parseInt((String) colorTextView2.getText());
					b = Integer.parseInt((String) colorTextView3.getText());
					colorTextView.setBackgroundColor(Color.argb(255,p2, g, b));
				}
				@Override
				public void onStartTrackingTouch(SeekBar p1){}
				@Override
				public void onStopTrackingTouch(SeekBar p1){}
			});
		SeekBar colorSeekBar2 = (SeekBar)dialogView.findViewById(R.id.colorSeekBar2);
		colorSeekBar2.setMax(255);
		colorSeekBar2.setProgress(0);
		colorSeekBar2.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
				@Override
				public void onProgressChanged(SeekBar p1, int p2, boolean p3){
					String y = Integer.toString(p2);
					colorTextView2.setText(y+"");
					a=Integer.parseInt((String) colorTextView1.getText());
					r = Integer.parseInt((String) colorTextView1.getText());
					b = Integer.parseInt((String) colorTextView3.getText());
					colorTextView.setBackgroundColor(Color.argb(255,r, p2, b));
				}
				@Override
				public void onStartTrackingTouch(SeekBar p1){}
				@Override
				public void onStopTrackingTouch(SeekBar p1){}
			});
		SeekBar colorSeekBar3 = (SeekBar)dialogView.findViewById(R.id.colorSeekBar3);
		colorSeekBar3.setMax(255);
		colorSeekBar3.setProgress(0);
		colorSeekBar3.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
				@Override
				public void onProgressChanged(SeekBar p1, int p2, boolean p3){

					String p = Integer.toString(p2);
					colorTextView3.setText(p+"");
					r = Integer.parseInt((String) colorTextView1.getText());
					g = Integer.parseInt((String) colorTextView1.getText());
					a=Integer.parseInt((String) colorTextView1.getText());
					colorTextView.setBackgroundColor(Color.argb(255,r, g, p2));
				}
				@Override
				public void onStartTrackingTouch(SeekBar p1){}
				@Override
				public void onStopTrackingTouch(SeekBar p1){}
			});
		customizeDialog.setPositiveButton("确定",
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					ima.setBackgroundColor(Color.argb(255,r,g,b));
				}
			});
		customizeDialog.setNegativeButton("取消", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2){

				}
			});
		customizeDialog.show();
	}
	
}
